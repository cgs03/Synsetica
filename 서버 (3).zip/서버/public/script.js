document.getElementById("start-button").addEventListener("click", startRecognition);
document.getElementById("create-video").addEventListener("click", createVideo);

let isRecognizing = false;

// Runway API 키 (보안상의 이유로 서버에서 관리하는 것을 권장)
const apiKey = "key_c8b333a930b91a22f41af26037509195a48ab388bddc2b2d2d34e650013a308ef123ea200813103acf94e605b023b77ff7b33d7487b798fd12d7b93a762d9496";

function startRecognition() {
    isRecognizing = true;
    document.getElementById("output").innerText = "노래 인식 중...";
    
    // 15초 후 인식 완료
    setTimeout(() => {
        isRecognizing = false;
        document.getElementById("output").innerText = "노래 인식이 종료되었습니다.";
        document.getElementById("create-video").disabled = false; // 영상 만들기 버튼 활성화
    }, 15000);
}

async function createVideo() {
    document.getElementById("output").innerText = "영상을 생성 중입니다...";

    // Runway API 예시 요청
    const response = await fetch("https://api.runwayml.com/v1/model/Gen-3 Alpha Turbo/generate", {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            // API 모델 입력값
            "input": {
                "duration": 20,
                // 추가 파라미터 설정
            }
        })
    });

    if (response.ok) {
        const data = await response.json();

        // 비디오 URL이 있는지 확인
        if (data.result_url) {
            // 새 창 열기
            const popup = window.open("", "popup", "width=800,height=600");
            popup.document.write(`
                <html>
                    <head>
                        <title>Generated Video</title>
                    </head>
                    <body style="display: flex; justify-content: center; align-items: center; height: 100%; margin: 0;">
                        <video controls autoplay src="${data.result_url}" style="max-width: 100%; max-height: 100%;"></video>
                    </body>
                </html>
            `);
            document.getElementById("output").innerText = "영상 생성 완료!";
        } else {
            document.getElementById("output").innerText = "비디오 URL이 없습니다.";
        }
    } else {
        console.error("API 요청 실패:", response.status, response.statusText); // 오류 상태 코드 확인
        document.getElementById("output").innerText = "영상 생성에 실패했습니다.";
    }
}
