const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// 'public' 폴더에서 정적 파일을 제공하도록 설정합니다.
app.use(express.static(path.join(__dirname, 'public')));

// 루트 경로로 접근했을 때 'main.html' 파일을 응답으로 보냅니다.
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'main.html'));
});

// 서버를 지정한 포트에서 실행합니다.
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});